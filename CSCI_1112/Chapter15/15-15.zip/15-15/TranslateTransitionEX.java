import javafx.animation.TranslateTransition; 
import javafx.animation.*; 
//import javafx.animation.Timeline; 
import javafx.application.Application; 
import javafx.scene.Group; 
import javafx.scene.*; 
import javafx.scene.paint.Color; 
import javafx.scene.shape.*; 
import javafx.stage.Stage; 
import javafx.util.Duration; 
import javafx.scene.layout.Pane; 
import javafx.scene.input.MouseButton; 
         
public class TranslateTransitionEX extends Application { 
   @Override 
   public void start(Stage stage) {  
      //Drawing a Circle 
      Rectangle circle = new Rectangle(); 
	  Pane pane = new Pane(); 
      
      //Setting the position of the circle 
      circle.setX(150.0f); 
      circle.setY(135.0f); 
      
      //Setting the radius of the circle 
      circle.setHeight(100.0f); 
	   circle.setWidth(100.0f); 
      
      //Setting the color of the circle 
      circle.setFill(Color.CYAN); 
	  Polygon pentagon = new Polygon();
		pentagon.getPoints().addAll( new Double[]{
			300.0,50.0,
			400.0,100.0,
			350.0,200.0,
			250.0,200.0,
			200.0,100.0 
			
			
			
			
			
			
		});
		pentagon.setFill(Color.RED);
      
      //Setting the stroke width of the circle 
      circle.setStrokeWidth(20); 
       Path movement = new Path(); 
	   //movement.getElements().add (new MoveTo (300f,150f));
	    //movement.getElements().add (new LineTo (50f,100f));
	   
		
      //Creating Translate Transition 
    PathTransition pathTransition = new PathTransition(); 
	pathTransition.setPath(pentagon); 
	FadeTransition faddingEffect = new FadeTransition(Duration.millis(2000),circle);
	faddingEffect.setFromValue(0.9);
	faddingEffect.setToValue(0.1);
	faddingEffect.setCycleCount(Timeline.INDEFINITE);
	faddingEffect.setAutoReverse(false); 
	faddingEffect.play();
	pane.setOnMousePressed (e -> {
	if (e.getButton() == MouseButton.PRIMARY){
		pathTransition.play(); 
		//faddingEffect.play(); 
		
	} 
	else if (e.getButton() == MouseButton.SECONDARY)
	pathTransition.pause(); 
	//faddingEffect.pause(); 
	}
	
	
	
	
	);
		
		
	
      
      //Setting the duration of the transition  
      pathTransition.setDuration(Duration.millis(2000)); 
      
      //Setting the node for the transition 
      pathTransition.setNode(circle); 
      
      //Setting the value of the transition along the x axis. 
     // pathTransition.setByX(300); 
      
      //Setting the cycle count for the transition 
      pathTransition.setCycleCount(Timeline.INDEFINITE); 
      
      //Setting auto reverse value to false 
      pathTransition.setAutoReverse(false); 
      
      //Playing the animation 
      pathTransition.play(); 
         
      //Creating a Group object  
     // Group root = new Group(pentagon,circle); 
	 pane.getChildren().addAll(pentagon,circle); 
         
      //Creating a scene object 
      Scene scene = new Scene(pane, 600, 300);  
      
      //Setting title to the Stage 
      stage.setTitle("Translate transition example"); 
         
      //Adding scene to the stage 
      stage.setScene(scene); 
         
      //Displaying the contents of the stage 
      stage.show(); 
	  pane.requestFocus(); 
   }      
   public static void main(String args[]){ 
      launch(args); 
   } 
}